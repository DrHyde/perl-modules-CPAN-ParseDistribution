package Bad::Syntax;
use strict;
use warnings

$VERSION = this is a syntax error;
